﻿using ECOMM.Business.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECOMM.Business.Concrete
{
    public class FavouritesService :IFavouritesService
    {
    }
}
